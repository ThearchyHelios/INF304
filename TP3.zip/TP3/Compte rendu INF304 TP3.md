# Compte rendu INF304 TP3

<p align="right">EL-BOUCH ISMAIL JIANG Yilun MAMADOU DIALLO</p>

## Exercice 2

*Problème avec l'intersection:*

|                                                              |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| 2<br/>0 2<br/>2 2<br/>3 <br/>2 2<br/>0 2<br/>0 0<br/>1<br/>0 0<br/><br/>55 | Grâce à ce test nous voyons que l’intersection ne fonctionne pas (ici la valeur a l’adresse {0,0} est 32) , après l’intersection on ne trouve pas cette valeur dans le nouvel ensemble . |
| 1<br/>0 0<br/>16<br/>0 0 0 1 0 2 0 3 0 4 0 5 0 6 0 7 0 8<br/>0 9 0 10 0 11 0 12 0 13 0 14 0 15<br/>20<br/> 1 0 1 1 1 2 2 1 2 2 2 3 3 2 3 3 3 4 4 3 4 4 4 5 0 15 0 14 15 014 15 15 14 3 0 14 3 1 9 <br/><br/>617 | Avec ce test on voit que l’intersection de (2n3)n(2n3) ne donne pas (2n3) , on voit encore un problème avec l’intersection. |

*Problèmes avec l’union :*

|                                                              |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| 1<br/>0 0<br/>2<br/>3 4<br/>0 0<br/>2<br/>0 0<br/>3 4<br/>31 | On remarque que l’union ne fonctionne pas avec ce jeu de test. |

## Exercice 3

La boite-noir qui fonctionne est la numéro 4.