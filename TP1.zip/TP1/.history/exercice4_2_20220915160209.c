/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 16:02:09
 * @LastEditTime: 2022-09-15 16:02:09
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP1/exercice4_2.c
 */
