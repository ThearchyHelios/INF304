/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 15:53:08
 * @LastEditTime: 2022-09-15 15:53:08
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP1/exercice4.c
 */


// Question 4: 