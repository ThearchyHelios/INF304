/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 10:58:14
 * @LastEditTime: 2022-09-22 10:58:15
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP1/exercice2.c
 */
