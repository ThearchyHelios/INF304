/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 11:01:55
 * @LastEditTime: 2022-09-22 11:01:55
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP1/exercice1.c
 */


#include <stdio.h>

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("Usage: <input file> <output file>");
        return 1;
    }
    else
    {
        printf("Input format est bon");
        return 0
    }
}