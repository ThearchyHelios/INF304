/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 15:34:59
 * @LastEditTime: 2022-09-15 15:34:59
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP1/exercice3.c
 */


