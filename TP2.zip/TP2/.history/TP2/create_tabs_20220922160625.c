/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 16:02:38
 * @LastEditTime: 2022-09-22 16:05:52
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/create_tabs.c
 */


#include <stdio.h>

#include "type_tableau.h"

// create tabs with the number entered

int main(int argc, char **argv)
{
    int nombre_fichers;
    printf("Entrez le nombre de fichiers à créer : ");
    
}