/*
 * @Author: ThearchyHelios
 * @Date: 2020-11-03 16:10:26
 * @LastEditTime: 2022-09-22 15:46:30
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/test_tri.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "es_tableau.h"
#include "tri.h"

void test_tri_insertion(int argc, char **argv)
{ /* À compléter */

}

void test_tri_insertion_alea(int argc, char **argv)
{ /* À compléter */
}
