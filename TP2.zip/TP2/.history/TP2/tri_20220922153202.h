/*
 * @Author: ThearchyHelios
 * @Date: 2020-11-03 16:10:26
 * @LastEditTime: 2022-09-22 15:32:02
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/tri.h
 */
#ifndef _TRI_H_
#define _TRI_H_

#include "type_tableau.h"

void tri_insertion(tableau_entiers *t);

#endif /* _TRI_H_ */

