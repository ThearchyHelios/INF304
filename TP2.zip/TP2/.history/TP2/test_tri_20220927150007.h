/*
 * @Author: ThearchyHelios
 * @Date: 2020-11-03 16:10:26
 * @LastEditTime: 2022-09-27 15:00:07
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/test_tri.h
 */
#ifndef _TEST_TRI_H_
#define _TEST_TRI_H_

void test_tri_insertion(int argc, char **argv);

void test_tri_insertion_alea(int argc, char **argv);

#endif
