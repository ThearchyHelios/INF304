#ifndef _TEST_TRI_H_
#define _TEST_TRI_H_

void test_tri_insertion(int argc, char **argv);

void test_tri_insertion_alea(int argc, char **argv);

#endif
