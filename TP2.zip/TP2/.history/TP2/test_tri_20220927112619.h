/*
 * @Author: ThearchyHelios
 * @Date: 2020-11-03 16:10:26
 * @LastEditTime: 2022-09-27 11:26:19
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/test_tri.h
 */
#ifndef _TEST_TRIH
#define _TEST_TRIH

void test_tri_insertion(int argc, char argv[]);

void test_tri_insertion_alea(int argc, charargv[]);

#endif