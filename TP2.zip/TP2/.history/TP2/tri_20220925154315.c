/*
 * @Author: ThearchyHelios
 * @Date: 2020-11-03 16:10:26
 * @LastEditTime: 2022-09-25 15:42:55
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/tri.c
 */

#include "tri.h"

/*
tri_insertion
Donnees : t : tableau d'entiers de taille > n, n : entier > 0
Resultat : le tableau t est trie en ordre croissant
*/
void tri_insertion(tableau_entiers *t)
{
    int i, j, tmp;
    for (i = 1; i < t->taille; i++)
    {
        tmp = t->tab[i];
        j = i - 1;
        while (j >= 0 && t->tab[j] > tmp)
        {
            t->tab[j] = t->tab[j];
            j--;
        }
        t->tab[j + 1] = tmp;
    }
}
