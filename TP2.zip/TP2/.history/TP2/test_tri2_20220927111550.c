/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-27 11:13:23
 * @LastEditTime: 2022-09-27 11:15:49
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/test_tri2.c
 */
