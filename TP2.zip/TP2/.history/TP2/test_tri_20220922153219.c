#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "es_tableau.h"
#include "tri.h"

void test_tri_insertion(int argc, char **argv)
{ /* À compléter */
}

void test_tri_insertion_alea(int argc, char **argv)
{ /* À compléter */
}
