/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 16:02:38
 * @LastEditTime: 2022-09-22 16:04:43
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/create_tabs.c
 */


#include <stdio.h>

#include "type"

int main(int argc, char **argv)
{
    tableau_entiers t;
    FILE *ftab;
    char nom_fichier[256];

    if (argc < 2)
    {
        printf("Usage: %s <fichier d'entree>\n", argv[0]);
    }
    else
    {
        lire_tableau(argv[1], &t);
        tri_insertion(&t);
        strcpy(nom_fichier, argv[1]);
        strcat(nom_fichier, ".out");
        ecrire_tableau(nom_fichier, &t);
    }
}