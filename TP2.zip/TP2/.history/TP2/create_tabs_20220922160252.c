/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 16:02:38
 * @LastEditTime: 2022-09-22 16:02:41
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/TP2/create_tabs.c
 */


#include <stdio.h>

#include "type_tableau.h"

