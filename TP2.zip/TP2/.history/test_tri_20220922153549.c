/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 15:31:04
 * @LastEditTime: 2022-09-22 15:35:49
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/test_tri.c
 */


#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#include "TP2/tri.h"

