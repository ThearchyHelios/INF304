/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 15:31:04
 * @LastEditTime: 2022-09-22 15:36:53
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/test_tri.c
 */


#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#include "TP2/tri.h"

// Generate a list of random numbers

void generate_random_list(int *list, int size)
{
    int i;
    srand(time(NULL));
    for (i = 0; i < size; i++)
    {
        list[i] = rand() % 100;
    }
}

void 