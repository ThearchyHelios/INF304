/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 15:31:04
 * @LastEditTime: 2022-09-22 15:41:43
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/test_tri.c
 */


#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#include "TP2/tri.h"

// Generate a list of random numbers

void generate_random_list(int *list, int size)
{
    int i;
    srand(time(NULL));
    for (i = 0; i < size; i++)
    {
        list[i] = rand() % 100;
    }
}

// Test the function tri

void test_tri_insertion(int argc, char **argv)
{
    int i;
    int size = 10;
    int list[size];
    tableau_entiers t;
    generate_random_list(list, size);
    t.taille = size;
    for (i = 0; i < size; i++)
    {
        t.tab[i] = list[i];
    }
    tri_insertion(&t);
    for (i = 0; i < size; i++)
    {
        printf("%d ", t.tab[i]);
    }
    printf("