/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-22 15:31:04
 * @LastEditTime: 2022-09-22 15:31:04
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /TP2/test_tri.c
 */


