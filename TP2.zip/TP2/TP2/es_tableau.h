#ifndef _ES_TABLEAU_H_
#define _ES_TABLEAU_H_

#include "type_tableau.h"

void lire_tableau(char *nomFichier, tableau_entiers *t);

void ecrire_tableau(char *nomFichier, tableau_entiers *t);

#endif /* _ES_TABLEAU_H_ */
